def suma(num1, num2):
    resultado = num1 + num2

    return f"{num1} + {num2} = {resultado}"

def resta(num1, num2):
    resultado = num1 - num2

    return f"{num1} - {num2} = {resultado}"

def multiplicacion(num1, num2):
    resultado = num1 * num2

    return f"{num1} x {num2} = {resultado}"

def potencia(num1, num2):
    num1 = float(num1)
    
    num2 = float(num2)

    resultado = num1**num2

    return resultado

