from setuptools import setup

setup(
    name="operacionesBasicas",
    version="1.0",
    description="Funciones Matematicas Basicas",
    author="Hamel",
    packages=["modulos","modulos.operacionesMatematicas","modulos.operacionesMatematicas.operacionesBasicas"]
)